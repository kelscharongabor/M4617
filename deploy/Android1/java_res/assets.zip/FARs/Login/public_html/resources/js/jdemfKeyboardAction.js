//this function depends on the pushPageButton function in jdemfJavascipt.js file, include both files 
$(window).keypress(function (e) {   
    if (e.keyCode == 13) {
        //can either press the login button or the OK button for config URL
        var elementCB3 = document.getElementById('cb3');
        if (elementCB3) {
            pushPageButton("cb3");
        }
        var elementCB2 = document.getElementById('cb2');
        if (elementCB2) {
            pushPageButton("cb2");
        }
    }
})();