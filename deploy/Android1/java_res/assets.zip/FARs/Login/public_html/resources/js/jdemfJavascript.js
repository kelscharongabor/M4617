(function () {
    showLoadingIndicator = function () {
        adf.mf.api.amx.showLoadingIndicator();

        clearTimeout(adf.mf.internal.amx._failSafeTimer);
        adf.mf.internal.amx._failSafeTimer = window.setTimeout(adf.mf.internal.amx.killLoadingIndicator, 1E9);

    };
    
     pushPageButton = function () {
        if (arguments.length == 1) {
            var element = document.getElementById(arguments[0]);
            if (element) {
                executeCustomEvent(element, "touchstart");
                executeCustomEvent(element, "touchend");
            }
        }
    }

    function executeCustomEvent(eventTarget, eventType) {
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent(eventType, true, true);
        evt.view = window;
        evt.altKey = false;
        evt.ctrlKey = false;
        evt.shiftKey = false;
        evt.metaKey = false;
        eventTarget.dispatchEvent(evt);
    }

})();
